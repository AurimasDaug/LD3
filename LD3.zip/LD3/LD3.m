clear all
clc

%default
x = 0.1:1/22:1;
m = linspace(0.1, 1, 100);
y = ((1 + 0.6*sin(2*pi*x/0.7)) + 0.3*sin(2*pi*x))/2;
%weights
w0 = randn(1);
w1 = randn(1);
w2 = randn(1);
%RBF
c1 = 0.19;
c2 = 0.91;
r1 = 0.16;
r2 = 0.15;

mok_zing = 0.8;
for k=1:10000
    for n=1:20
        
      F1=exp(-((x(n)-c1)^2)/(2*(r1^2)));
      F2=exp(-((x(n)-c2)^2)/(2*(r2^2)));
      y_aps(n) = F1*w1+F2*w2+w0;
      e = y(n)-y_aps(n);
      w1 = w1 + mok_zing*e*F1;
      w2 = w2 + mok_zing*e*F2;
      w0 = w0 + mok_zing*e;
      
    end
end

for n=1:100

    F1=exp(-((m(n)-c1)^2)/(2*(r1^2)));
    F2=exp(-((m(n)-c2)^2)/(2*(r2^2)));

    y_aps(n) = F1*w1+F2*w2+w0;

end
plot(x, y, "k", m, y_aps, "r--")